<?php 
require_once("../../../DB.php");
class IssuancedetailsDBO extends DB{
	var $fetchObject;
	var $sql;
	var $id;
	var $result;
	var $affectedRows;
 var $table="inv_issuancedetails";

	function persist($obj){
		$sql="insert into inv_issuancedetails(id,issuanceid,itemid,quantity, costprice, total,purpose,blockid,sectionid,greenhouseid,fleetid,remarks,ipaddress,createdby,createdon,lasteditedby,lasteditedon)
						values('','$obj->issuanceid',$obj->itemid,'$obj->quantity','$obj->costprice','$obj->total','$obj->purpose',$obj->blockid,$obj->sectionid,$obj->greenhouseid,$obj->fleetid,'$obj->remarks','$obj->ipaddress','$obj->createdby','$obj->createdon','$obj->lasteditedby','$obj->lasteditedon')";		
		$this->sql=$sql;//echo $sql;
		if(empty($obj->effectjournals)){
		  if(mysql_query($sql,$this->connection)){		
			  $this->id=mysql_insert_id();
			  return true;	
		  }
		}else{
		  return true;
		}			
	}		
 
	function update($obj,$where=""){			
		if(empty($where)){
			$where="id='$obj->id'";
		}
		$sql="update inv_issuancedetails set issuanceid='$obj->issuanceid',itemid=$obj->itemid,quantity='$obj->quantity',remarks='$obj->remarks',ipaddress='$obj->ipaddress',lasteditedby='$obj->lasteditedby',lasteditedon='$obj->lasteditedon' where $where ";
		$this->sql=$sql;
		if(mysql_query($sql,$this->connection)){		
			return true;	
		}
	}			
 
	function delete($obj,$where=""){			
		if(empty($where)){
			$where=" where id='$obj->id' ";
		}
		$sql="delete from inv_issuancedetails $where ";
		$this->sql=$sql;
		if(mysql_query($sql,$this->connection))		
				return true;	
	}			
 
	function retrieve($fields,$join,$where,$having,$groupby,$orderby){			
		$sql="select $fields from inv_issuancedetails $join $where $groupby $having $orderby"; 
 		$this->sql=$sql;
		$this->result=mysql_query($sql,$this->connection);
		$this->affectedRows=mysql_affected_rows();
		$this->fetchObject=mysql_fetch_object(mysql_query($sql,$this->connection));
	}			
}			
?>

