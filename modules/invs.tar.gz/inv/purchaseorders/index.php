<?php
session_start();

require_once("../../../lib.php");
redirect("../../inv/items/");
?>
