<?php
require_once("../../lib.php");
redirect("../../index.php");
?>
