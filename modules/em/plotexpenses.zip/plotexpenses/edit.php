<?php
session_start();
require_once("../../../lib.php");

$obj=$_SESSION['obj'];
$action=$_GET['action'];
$i=$_GET['i'];
$edit=$_GET['edit'];

$shpplotexpenses=$_SESSION['shpplotexpenses'];

if($action=="edit"){
	$obj->expenseid=$shpplotexpenses[$i]['expenseid'];
	$obj->quantity=$shpplotexpenses[$i]['quantity'];
	$obj->amount=$shpplotexpenses[$i]['amount'];
	$obj->remarks=$shpplotexpenses[$i]['remarks'];

	$_SESSION['obj']=$obj;
}

$obj->iterator-=1;

//removes the identified row
$shpplotexpenses1=array_slice($shpplotexpenses,0,$i);
$shpplotexpenses2=array_slice($shpplotexpenses,$i+1);
$shpplotexpenses=array_merge($shpplotexpenses1,$shpplotexpenses2);

$_SESSION['shpplotexpenses']=$shpplotexpenses;

redirect("addplotexpenses_proc.php?edit=1");
?>
